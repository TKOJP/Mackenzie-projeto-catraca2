# [NOME DA DISCIPLINA] X sem. 20XX

## Turma XXX
## Projeto: "nome do projeto"
## Integrantes do grupo:

* Aluno 1
* Aluno 2
* Aluno 3
* Aluno 4

## Descrição resumida do projeto

Descreva resumidamente o projeto aqui.

_______________________________________
Obs:

`src/` deve conter os códigos desenvolvidos

`doc/` documentação do projeto
