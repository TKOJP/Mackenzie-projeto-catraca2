# Nesta seção devem ser descritas:
1. Interfaces de rede utilizadas (shield GPRS, Ethernet, Modulos Wifi, etc)
2. Protocolos (Firmata, MQTT, CoAP, HTTP, etc)
3. Descrição de aplicativos desenvolvidos, dashboards, IHM e demais interfaces com o usuário desenvolvidas (layouts e moockups)
