# Descriçao do Hardware

Deve conter:

1) Lista de Peças (descrição e imagens, quando disponíveis)

2) Desenho Tinkercad ou Fritzing

3) Esquema eletrônico

4) Materiais para confecção de caixas e consoles (ou arquivos para impressão 3D)
